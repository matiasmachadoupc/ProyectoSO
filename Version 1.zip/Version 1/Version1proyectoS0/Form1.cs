using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace Version1proyectoS0
{
    public partial class Form1 : Form
    {
        Socket server;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }


        private void button1_Click_1(object sender, EventArgs e)
        {
            //Creamos un IPEndPoint con el ip del servidor y puerto del servidor 
            //al que deseamos conectarnos
            IPAddress direc = IPAddress.Parse("192.168.56.102");
            IPEndPoint ipep = new IPEndPoint(direc, 9050);


            //Creamos el socket 
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep);//Intentamos conectar el socket
                this.BackColor = Color.Green;
                MessageBox.Show("Conectado");

            }
            catch (SocketException ex)
            {
                //Si hay excepcion imprimimos error y salimos del programa con return 
                MessageBox.Show("No he podido conectar con el servidor");
                return;
            }
        }
        private void Registrarse_Click(object sender, EventArgs e)
        {
            if (Contra_Re.Text == ConfContra_Re.Text)
            {
                string mensaje = "1/" + Nombre_Re.Text + "/" + Contra_Re.Text;
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
            else if (Contra_Re.Text != ConfContra_Re.Text)
                MessageBox.Show("Hay datos que no coinciden");

            string respuesta;
            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            respuesta = Encoding.ASCII.GetString(msg2);
            if (respuesta == "0")
                MessageBox.Show("El usuario se ha registrado correctamente");
            else if (respuesta == "1")
                MessageBox.Show("Error al registrarse, el nombre de usuario seleccionado ya existe");
            else
                MessageBox.Show("Se ha producido un error, porfavor intentelo de nuevo");
        }
        private void Iniciar_Click(object sender, EventArgs e)
        {
            string mensaje = "2/" + Nombre_In.Text + "/" + Contra_In.Text;
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            string respuesta;
            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            respuesta = Encoding.ASCII.GetString(msg2);

            if (respuesta == "0")
                MessageBox.Show("Se ha iniciado sesion correctamente");
            else if (respuesta == "1")
                MessageBox.Show("El usuario no esta registrado");
            else if (respuesta == "2")
                MessageBox.Show("Contrase�a incorrecta");
            else
                MessageBox.Show("Se ha producido un error, porfavor intentelo de nuevo");


        }

        private void RealizarPeticion_Click(object sender, EventArgs e)
        {
            if (Peticion1.Checked)
            {
                string mensaje = "3/" + Nombres_Pet.Text;
                // Enviamos al servidor el nombre tecleado
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

                //Recibimos la respuesta del servidor
                byte[] msg2 = new byte[80];
                server.Receive(msg2);
                mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
                MessageBox.Show("Las fechas de las partidas del jugador son:" + mensaje);
            }
            else if (Peticion2.Checked)
            {
                string mensaje = "4/" + Nombres_Pet.Text;
                // Enviamos al servidor el nombre tecleado
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

                //Recibimos la respuesta del servidor
                byte[] msg2 = new byte[80];
                server.Receive(msg2);
                mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];


                MessageBox.Show("El ganador de la partida de la fecha indicada es:" + mensaje);
            }
            else if (Peticion3.Checked)
            {
                string mensaje = "5/" + Nombres_Pet.Text;
                // Enviamos al servidor el nombre tecleado
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

                //Recibimos la respuesta del servidor
                byte[] msg2 = new byte[80];
                server.Receive(msg2);
                mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];


                MessageBox.Show(mensaje);
            }
        }


        private void button3_Click(object sender, EventArgs e)
        {
            //Mensaje de desconexi�n
            string mensaje = "0/";

            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            // Nos desconectamos
            this.BackColor = Color.Gray;
            server.Shutdown(SocketShutdown.Both);
            server.Close();


        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radio_Pet1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }


    }
}